// src/main/java/com/example/demo/controller/OrderController.java
package com.example.demo.controller;

import com.example.demo.service.OrderService;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderController {

    private final OrderService orderService;

    // 构造函数注入 Service
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * 下单接口：最简单版
     * 调用方式示例（先这样，后面可以改成 JSON）：
     *   POST http://localhost:8080/orders?userId=1&productId=1&quantity=2
     */
    @PostMapping("/orders")
    public Long placeOrder(@RequestParam Long userId,
                           @RequestParam Long productId,
                           @RequestParam int quantity) {
        return orderService.placeOrder(userId, productId, quantity);
    }

    // 临时测试接口：访问 /orders/test 就下一个固定的订单
    @GetMapping("/orders/test")
    public Long testOrder() {
        // 假设：userId=1，买 productId=1，这个商品买 2 个
        return orderService.placeOrder(1L, 1L, 2);
    }

}

