// src/main/java/com/example/demo/controller/ProductController.java
package com.example.demo.controller;

import com.example.demo.model.Product;
import com.example.demo.service.RedisDataTypeService;
import com.example.demo.service.ProductService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductController {

    private final ProductService productService;
    private final RedisDataTypeService redisDataTypeService;

    // 构造函数注入 Service
    public ProductController(ProductService productService, RedisDataTypeService redisDataTypeService) {
        this.productService = productService;
        this.redisDataTypeService = redisDataTypeService;
    }

    // GET /products  → 商品列表
    @GetMapping("/products")
    public List<Product> listProducts() {
        return productService.getAllProducts();
    }

    // GET /products/{id}  → 商品详情
    @GetMapping("/products/{id}")
    public Product getProduct(
            @PathVariable Long id,
            @RequestParam(name = "userId", defaultValue = "1") Long userId
    ) {
        // ① 先拿商品（这里可能来自 Redis 缓存，也可能来自 MySQL 回源）
        Product product = productService.getProductById(id);

        // ② 无论商品是从缓存拿到的还是从 DB 查到的，只要“用户访问了商品详情”，
        //    我们都应该记录这次访问（这就是“业务数据” vs “缓存数据”的区别）。
        //
        //    这一步会同时演示 4 种 Redis 数据类型：
        //    - String：浏览量计数
        //    - ZSet：热门榜（按浏览量排序）
        //    - List：用户最近浏览
        //    - Hash：缓存一个“可按字段读取”的商品快照
        if (product != null) {
            redisDataTypeService.recordProductView(userId, product);
        }

        return product;
    }

    /**
     * 测试用：清除某个商品的缓存。
     * 调用方式示例：
     *   POST http://localhost:8080/products/1/evict
     */
    @PostMapping("/{id}/evict")
    public void evictProductCache(@PathVariable Long id) {
        productService.evictProductCache(id);
    }

    // ✅ 兼容你更直觉的调用方式：POST /products/{id}/evict
    @PostMapping("/products/{id}/evict")
    public void evictProductCache2(@PathVariable Long id) {
        productService.evictProductCache(id);
    }
}
