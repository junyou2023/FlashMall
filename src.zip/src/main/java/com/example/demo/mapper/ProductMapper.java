// src/main/java/com/example/demo/mapper/ProductMapper.java
package com.example.demo.mapper;

import com.example.demo.model.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ProductMapper {

    // 查询全部商品
    List<Product> findAll();

    // 根据 id 查询单个商品
    Product findById(@Param("id") Long id);

    // 更新库存（只改 stock 字段）
    int updateStock(@Param("id") Long id, @Param("stock") int stock);
}
