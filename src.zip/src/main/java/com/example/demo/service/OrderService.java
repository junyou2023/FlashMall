// src/main/java/com/example/demo/service/OrderService.java
package com.example.demo.service;

import com.example.demo.mapper.OrderItemMapper;
import com.example.demo.mapper.OrderMapper;
import com.example.demo.mapper.ProductMapper;
import com.example.demo.model.Order;
import com.example.demo.model.OrderItem;
import com.example.demo.model.Product;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class OrderService {

    private final OrderMapper orderMapper;
    private final OrderItemMapper orderItemMapper;
    private final ProductMapper productMapper;

    public OrderService(OrderMapper orderMapper,
                        OrderItemMapper orderItemMapper,
                        ProductMapper productMapper) {
        this.orderMapper = orderMapper;
        this.orderItemMapper = orderItemMapper;
        this.productMapper = productMapper;
    }

    /**
     * 最小版下单流程：一个用户购买一个商品（quantity 数量）
     *
     * @Transactional 的本质：
     *  - 把下面所有数据库操作包在一个事务里
     *  - 要么全部成功，要么全部回滚（商品库存 / 订单 / 明细保持一致）
     */
    @Transactional
    public Long placeOrder(Long userId, Long productId, int quantity) {
        // 1. 查询商品并检查库存
        Product product = productMapper.findById(productId);
        if (product == null) {
            throw new RuntimeException("商品不存在");
        }
        if (product.getStock() < quantity) {
            throw new RuntimeException("库存不足");
        }

        // 2. 扣减库存
        int newStock = product.getStock() - quantity;
        int updatedRows = productMapper.updateStock(productId, newStock);
        if (updatedRows != 1) {
            throw new RuntimeException("扣减库存失败");
        }

        // 3. 计算总价
        double totalPrice = product.getPrice() * quantity;

        // 4. 创建订单主表
        Order order = new Order();
        order.setUserId(userId);
        order.setTotalPrice(totalPrice);
        order.setStatus("CREATED");
        order.setCreatedAt(LocalDateTime.now());

        int inserted = orderMapper.insert(order);
        if (inserted != 1) {
            throw new RuntimeException("创建订单失败");
        }

        // 5. 创建订单明细
        OrderItem item = new OrderItem();
        item.setOrderId(order.getId());
        item.setProductId(productId);
        item.setQuantity(quantity);
        item.setPrice(product.getPrice());

        int insertedItem = orderItemMapper.insert(item);
        if (insertedItem != 1) {
            throw new RuntimeException("创建订单明细失败");
        }

        // 6. 返回订单ID
        return order.getId();
    }
}

